#ifndef CLAUSEOFFSET_H
#define CLAUSEOFFSET_H

#ifdef _MSC_VER
#include <msvc/stdint.h>
#else
#include <stdint.h>
#endif //_MSC_VER

namespace CMSat {

typedef uint32_t ClauseOffset;

}

#endif //CLAUSEOFFSET_H
